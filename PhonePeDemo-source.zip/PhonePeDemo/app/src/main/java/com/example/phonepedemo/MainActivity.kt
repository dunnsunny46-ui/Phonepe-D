package com.example.phonepedemo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Purple = Color(0xFF5F259F)
private val Pale = Color(0xFFF5F0FA)
private val Ink = Color(0xFF211B26)

data class DemoTransaction(
    val id: Long,
    val title: String,
    val amount: Double,
    val currency: String,
    val kind: String,
    val timestamp: Long = System.currentTimeMillis()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhonePeDemoApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhonePeDemoApp() {
    var currency by remember { mutableStateOf("INR") }
    var balanceINR by remember { mutableDoubleStateOf(2500.00) }
    var balanceNGN by remember { mutableDoubleStateOf(50000.00) }
    var page by remember { mutableStateOf("Home") }
    var amountText by remember { mutableStateOf("") }
    var recipient by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("Demo mode — no real money moves.") }
    var transactions by remember {
        mutableStateOf(
            listOf(
                DemoTransaction(1, "Demo wallet added", 2500.0, "INR", "Credit"),
                DemoTransaction(2, "Sample payment", 350.0, "INR", "Debit")
            )
        )
    }

    val balance = if (currency == "INR") balanceINR else balanceNGN
    val symbol = if (currency == "INR") "₹" else "₦"

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple,
            secondary = Color(0xFF8A50C7),
            background = Pale,
            surface = Color.White,
            onBackground = Ink
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PhonePe Demo", fontWeight = FontWeight.Bold)
                            Text("Independent demo • not official PhonePe", fontSize = 10.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Purple,
                        titleContentColor = Color.White
                    ),
                    actions = {
                        Text(
                            currency,
                            color = Color.White,
                            modifier = Modifier
                                .padding(end = 16.dp)
                                .clickable { currency = if (currency == "INR") "NGN" else "INR" }
                        )
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Home", "History", "Profile").forEach { destination ->
                        NavigationBarItem(
                            selected = page == destination,
                            onClick = { page = destination },
                            icon = { Text(when (destination) {
                                "Home" -> "⌂"
                                "History" -> "↻"
                                else -> "●"
                            }, fontSize = 18.sp) },
                            label = { Text(destination) }
                        )
                    }
                }
            },
            containerColor = Pale
        ) { padding ->
            when (page) {
                "Home" -> HomePage(
                    modifier = Modifier.padding(padding),
                    balance = balance,
                    symbol = symbol,
                    currency = currency,
                    notice = notice,
                    onAdd = { page = "Add" },
                    onSend = { page = "Send" },
                    onReceive = { notice = "Demo receive screen: no real UPI ID or payment request is created." },
                    onHistory = { page = "History" }
                )
                "History" -> HistoryPage(Modifier.padding(padding), transactions, currency)
                "Profile" -> ProfilePage(Modifier.padding(padding), currency) {
                    currency = if (currency == "INR") "NGN" else "INR"
                }
                "Add", "Send" -> {
                    val isAdd = page == "Add"
                    Column(
                        Modifier.padding(padding).fillMaxSize().padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(if (isAdd) "Add demo funds" else "Send demo payment", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Currency: $currency. This action only changes fictional demo data.")
                        if (!isAdd) {
                            OutlinedTextField(
                                value = recipient,
                                onValueChange = { recipient = it },
                                label = { Text("Demo recipient name") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' }.take(12) },
                            label = { Text("Amount ($symbol)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                val amount = amountText.toDoubleOrNull()
                                if (amount == null || amount <= 0.0) {
                                    notice = "Enter a valid amount greater than zero."
                                } else if (!isAdd && amount > balance) {
                                    notice = "Insufficient demo balance."
                                } else {
                                    val title = if (isAdd) "Demo funds added" else "Demo payment to ${recipient.ifBlank { "Sample recipient" }}"
                                    if (currency == "INR") balanceINR += if (isAdd) amount else -amount
                                    else balanceNGN += if (isAdd) amount else -amount
                                    transactions = listOf(
                                        DemoTransaction(
                                            System.currentTimeMillis(),
                                            title,
                                            amount,
                                            currency,
                                            if (isAdd) "Credit" else "Debit"
                                        )
                                    ) + transactions
                                    notice = "Demo transaction recorded. No real payment was made."
                                    amountText = ""
                                    recipient = ""
                                    page = "Home"
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (isAdd) "Add demo funds" else "Simulate payment") }
                        OutlinedButton(onClick = { page = "Home" }, modifier = Modifier.fillMaxWidth()) {
                            Text("Cancel")
                        }
                        Text(notice, color = Purple, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun HomePage(
    modifier: Modifier,
    balance: Double,
    symbol: String,
    currency: String,
    notice: String,
    onAdd: () -> Unit,
    onSend: () -> Unit,
    onReceive: () -> Unit,
    onHistory: () -> Unit
) {
    LazyColumn(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Purple),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("DEMO WALLET BALANCE", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("$symbol ${"%,.2f".format(Locale.US, balance)}", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("$currency • Fictional funds only", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("DEMO ONLY — NOT A REAL BANK BALANCE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Money transfers", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionButton("＋", "Add funds", onAdd, Modifier.weight(1f))
                        ActionButton("↗", "Send", onSend, Modifier.weight(1f))
                        ActionButton("↓", "Receive", onReceive, Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Recent activity", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.weight(1f))
                        Text("View all", color = Purple, modifier = Modifier.clickable(onClick = onHistory))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Your demo transactions appear in Transaction History.", color = Color.Gray, fontSize = 13.sp)
                }
            }
        }
        item {
            Text(notice, color = Purple, fontSize = 12.sp)
            Text("This independent demo is not affiliated with PhonePe.", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
fun ActionButton(emoji: String, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Pale, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 24.sp, color = Purple)
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = Ink)
    }
}

@Composable
fun HistoryPage(modifier: Modifier, transactions: List<DemoTransaction>, currency: String) {
    LazyColumn(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Transaction History", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item { Text("Demo records only • selected currency: $currency", color = Color.Gray, fontSize = 12.sp) }
        if (transactions.isEmpty()) {
            item { Text("No demo transactions yet.") }
        } else {
            items(transactions) { tx ->
                val symbol = if (tx.currency == "INR") "₹" else "₦"
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(tx.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(tx.timestamp)),
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                            Text("DEMO • ${tx.kind}", color = Purple, fontSize = 10.sp)
                        }
                        Text(
                            (if (tx.kind == "Credit") "+" else "−") + symbol + "%,.2f".format(Locale.US, tx.amount),
                            fontWeight = FontWeight.Bold,
                            color = if (tx.kind == "Credit") Color(0xFF137547) else Ink
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProfilePage(modifier: Modifier, currency: String, onSwitchCurrency: () -> Unit) {
    Column(
        modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Demo Profile", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("Account type", color = Color.Gray, fontSize = 12.sp)
                Text("Local demonstration account", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                Text("Current display currency", color = Color.Gray, fontSize = 12.sp)
                Text(currency, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onSwitchCurrency) { Text("Switch INR / NGN") }
            }
        }
        Text("Authentication and cloud database are not configured in this starter build.", color = Color.Gray, fontSize = 13.sp)
        Text("Do not enter real banking credentials or use demo records as proof of payment.", color = Purple, fontSize = 12.sp)
    }
}
