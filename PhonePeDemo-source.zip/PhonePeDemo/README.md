# PhonePe Demo (independent demo app)

A clearly labeled, non-production Android wallet demo inspired by common payment-app patterns. It is **not** the official PhonePe app and does not connect to PhonePe, UPI, banks, or real payment rails.

## Included
- Kotlin + Jetpack Compose starter app
- Demo dashboard with INR/NGN currency selector
- Simulated add-money and send-money actions
- Transaction history stored locally with Room
- Firebase setup notes for adding real authentication/cloud sync later

## Build
1. Install Android Studio (current stable) and Android SDK.
2. Open this project folder in Android Studio.
3. Let Gradle sync.
4. Run on an emulator or Android device.

This source project is a starter template. You must build it with Android Studio to produce an APK. Firebase credentials and cloud services are not preconfigured.

## Safety
All funds and transactions are fictional. Do not use this app to collect real banking credentials, impersonate a financial institution, or represent simulated transfers as real payments.
